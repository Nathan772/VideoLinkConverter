package nate.company.youtube_converter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoutubeConverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoutubeConverterApplication.class, args);
	}

}
