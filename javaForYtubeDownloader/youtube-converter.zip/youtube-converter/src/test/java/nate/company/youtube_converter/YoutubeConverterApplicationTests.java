package nate.company.youtube_converter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoutubeConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
