#!/usr/bin/env python3

#ajouter une fonctionnalité de mutli-threading pour permettre le multi-téléchargement et autoriser l'utilisation d'une liste 
#d'argument
def main():
    print("est-ce que ça va s'afficher ???")

if __name__ == "__main__":
    main()